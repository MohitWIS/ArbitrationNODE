
		function myFunction() {
		  document.querySelector(".arbitrator-hid").style.display = "none";
		  document.querySelector(".arbitrator-shw").style.display = "block";
		}
		
		function myFunction2() {
		  document.querySelector(".arbitrator-shw").style.display = "none";
		  document.querySelector(".arbitrator-hid").style.display = "block";
		}
		