export enum SpaceType {
    DEFAULT = "default",
    PRESERVE = "preserve",
}
