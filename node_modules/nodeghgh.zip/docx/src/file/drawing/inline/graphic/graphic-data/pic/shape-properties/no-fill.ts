import { XmlComponent } from "file/xml-components";

export class NoFill extends XmlComponent {
    constructor() {
        super("a:noFill");
    }
}
