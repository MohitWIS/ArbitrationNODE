import { XmlComponent } from "file/xml-components";

export class SourceRectangle extends XmlComponent {
    constructor() {
        super("a:srcRect");
    }
}
