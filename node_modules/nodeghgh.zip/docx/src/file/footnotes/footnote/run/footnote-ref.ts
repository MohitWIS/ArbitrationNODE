import { XmlComponent } from "file/xml-components";

export class FootnoteRef extends XmlComponent {
    constructor() {
        super("w:footnoteRef");
    }
}
