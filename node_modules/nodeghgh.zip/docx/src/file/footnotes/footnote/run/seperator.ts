import { XmlComponent } from "file/xml-components";

export class Seperator extends XmlComponent {
    constructor() {
        super("w:separator");
    }
}
