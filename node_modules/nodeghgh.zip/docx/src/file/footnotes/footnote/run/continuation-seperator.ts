import { XmlComponent } from "file/xml-components";

export class ContinuationSeperator extends XmlComponent {
    constructor() {
        super("w:continuationSeparator");
    }
}
