import { XmlComponent } from "file/xml-components";

export class Bidirectional extends XmlComponent {
    constructor() {
        super("w:bidi");
    }
}
